package com.cg.sample.bean;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SaveStudent {
	
	public static void main(String[] args) {
		
		
		EntityManagerFactory e=Persistence.createEntityManagerFactory("Sample");
		EntityManager e1=e.createEntityManager();
		e1.getTransaction().begin();
		
		Student s1=new Student("101","abhi","cst");
		
		e1.persist(s1);
		
		
		e1.getTransaction().commit();
		e.close();
		
		
		
	}

}
