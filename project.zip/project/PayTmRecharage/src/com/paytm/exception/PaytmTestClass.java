package com.paytm.exception;


	

	import org.junit.After;
	import org.junit.Assert;
	import org.junit.Before;
	import org.junit.Test;

import com.paytm.bean.Paytm;
import com.paytm.dao.IPaytmDao;
import com.paytm.dao.PaytmDaoImpl;
public class PaytmTestClass {
		  IPaytmDao idao=null;
	@Before
		public void setup() {
		idao=new PaytmDaoImpl();
	}
	@After
	 public void teardown() {
		 idao=null;
	 }
	@Test
	 
	public void emptest() {
		Paytm e=new Paytm("Damo","Postpaid","recharged 999 rupees","Rc999",5000,"7339353332",4001, "04/01/2019");
		e.setRcId(100);
		Assert.assertNotNull(e);
		
	}
	}

 