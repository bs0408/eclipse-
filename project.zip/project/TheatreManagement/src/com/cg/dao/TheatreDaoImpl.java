package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Theatre;
import com.cg.util.TheatresDB;

public class TheatreDaoImpl implements ITheatreDao {

	@Override
	public Theatre updateTheatre(int tid) {
		Theatre ob=null;
		if(TheatresDB.getTheatres()==null||TheatresDB.getTheatres().isEmpty()){
			//exc
		}
		else if(TheatresDB.getTheatres().containsKey(tid))
		{
			ob=TheatresDB.getTheatres().get(tid);
			ob.setPrice(400);
			System.out.println(ob);
		}
		else{
			//exc
		}
		return ob;
	}

	@Override
	public HashMap<Integer, Theatre> viewAllTheatres() {
		
		return TheatresDB.getTheatres();
	}

}



