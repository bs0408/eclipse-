package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Theatre;
import com.cg.dao.ITheatreDao;
import com.cg.dao.TheatreDaoImpl;

public class TheatreServiceImpl implements ITheatreService{

	ITheatreDao idao=null;
	
	@Override
	public Theatre updateTheatre(int tid) {
		idao=new TheatreDaoImpl();
		
		return idao.updateTheatre(tid);
	}

	@Override
	public HashMap<Integer, Theatre> viewAllTheatres() {
		idao=new TheatreDaoImpl();
		
		return idao.viewAllTheatres();
	}
	
	
	
	
	

}
