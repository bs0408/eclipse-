package com.employeemanagement.bean;

public  class Employee {
	String empName,doj,pwd;
	int sal,empid;
	
	public Employee()
	{
		
	}
	
	public int getEmpid() {
		return empid;
	}
	public  void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}

	public Employee(String empName, String doj, String pwd, int sal) {
		super();
		this.empName = empName;
		this.doj = doj;
		this.pwd = pwd;
		this.sal = sal;
	}
	
	
}


